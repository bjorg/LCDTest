// Copyright 2004 Steve Bjorg
//
// This file is part of LCDTest.
// 
// LCDTest is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.

// LCDTest is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.

// You should have received a copy of the GNU General Public License
// along with LCDTest; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

#import "LCDControl.h"
#import "TestWindow.h"

@implementation LCDControl

- (void)showTestWindow:(TestMode)testMode {
	
	// create the test window
	TestWindow* test_window = [[TestWindow alloc] initFullScreenWithTestMode:testMode withScreen:[window screen]];
	
	// display the test window
	if(test_window) {
		[test_window setReleasedWhenClosed:YES];
		[test_window makeKeyAndOrderFront:nil];
	} else {
		NSRunAlertPanel(@"Error", @"The application was unable to create the window with the test pattern.",@"OK",nil,nil);
	}
}

- (IBAction)showDeadPixels:(id)sender {
	NSLog(@"show dead pixels patterns");
	[self showTestWindow:TESTMODE_DEAD_PIXELS];
}

- (IBAction)showColorGradient:(id)sender {
	NSLog(@"show color gradient pattern");
	[self showTestWindow:TESTMODE_COLOR_GRADIENT];
}

- (IBAction)showCalibration:(id)sender {
	NSLog(@"show calibration pattern");
	[self showTestWindow:TESTMODE_CALIBRATION];
}

- (IBAction)showPanelAlignment:(id)sender {
	NSLog(@"show panel alignment patterns");
	[self showTestWindow:TESTMODE_PANEL_ALIGNMENT];
}

- (IBAction)showPixelResponseTime:(id)sender {
	NSLog(@"show panel alignment patterns");
	[self showTestWindow:TESTMODE_PIXEL_RESPONSE_TIME];
}

- (IBAction)windowWillClose:(id)sender {
    [NSApp terminate:nil];
}

@end
